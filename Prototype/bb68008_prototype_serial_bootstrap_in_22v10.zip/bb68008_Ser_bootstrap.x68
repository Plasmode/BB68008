SerRx    equ $fffffff4
page     equ $fffffffe
         org $0
;serial bootstrap with 22V10
;serial receive is hooked up to D[7]
;CPU clock is 8MHz
         dc.l $8000
         dc.l start
         org $14
start:           
         lea $0,a0                 ;start serial load from $0  
         move.w #$200,d3            ;write 512 bytes into RAM
setup:         
         moveq #7,d1               ;8 bits in serial receive          
startBit:         
         move.b SerRx,d2   
         bmi startBit
         movem d0-d7/a0-a3,(a7)     ;wait 1.5 bit time     
getSer:         
         asl SerRx                  ; shift into extend bit
         roxr.b #1,d2                 ; D2 holds the received value       
         movem d0-d7,(a7)           ;wait 1 bit time
         dbra d1,getSer
         move.b d2,(a0)+
         dbra d3,setup  

         bra.s bootend               ;prefetch this instruction
         nop
bootend: 
;this is location $40        
;loaded program resume execution here.
         end  0           











*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
