;serial loader test
;513 bytes
;program loaded from $0-$200
SerRx    equ $fffffff4
SerTx1   equ $fffffff0
SerTx0   equ $fffffff2
         org $400

         lea hello_,a1              ;send Hello World message
nxtByte:         
         move.b (a1)+,d0
         beq msgdone
         jsr cout
         bra nxtByte
msgdone:

         nop                        ;spin here forever
         bra msgdone
cout:
;send regD0 to serial port
;bit bang at 57600
         lea $f000,a2               ;temporary locations for movem instr
         moveq #7,d1                ;8 bits of data
         move.b d0,serTx0           ;start bit
         movem d0-d7/a0-a1,(a2)     ;delay for start bit
shift8:              
         asr #1,d0                  ;examine & send data bit, lsb first
         bcc.s cout1
         move.b d0,serTx1
         bra.s cout2
cout1:
         move.b d0,serTx0
         nop                        ;balance out high and low levels
         nop
         nop
cout2:
         movem d0-d4,(a2)           ;inter-bit delay
         dbra d1,shift8 
         nop
         nop        
         move.b d0,serTx1           ;stop bit
         movem d0-d7,(a2)           ;stop bit delay before exiting
         rts         
hello_: dc.b 10,13,'Hello world'
         dc.b 10,13,'this is a test',10,13 
         dc.b 10,13,'1234567890abcdefghijklmnopqrstuvwxyz',10,13
         dc.b 'ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()',10,13,0         
         
         dcb.w $400,$5a     
         
         end $400     






*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
